#!/bin/sh

current_date_time="`date "+%Y-%m-%d %H:%M:%S"`";
echo $current_date_time;