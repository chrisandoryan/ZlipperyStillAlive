#!/bin/sh

pwd
ls
cat Flagnya_dimari.txt
